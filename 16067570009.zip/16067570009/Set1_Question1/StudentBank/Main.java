package com.StudentBank;
import java .util.Scanner;
public class Main
{
    public static void main(String[] args)
    {
        int ch;
        Account bk=new Account(2000);  
        Scanner sc=new Scanner(System.in);
        System.out.println("1.Existing account");
        System.out.println("2.Bank ");
        ch=sc.nextInt();
        if(ch==1)
        {
            bk.createexist();
        }
        else
        {
            bk.menu();
        }
    }
}